import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart'; // Firebase 설정 파일 (Firebase CLI로 생성)

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const TeamCookApp());
}

class TeamCookApp extends StatelessWidget {
  const TeamCookApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Team Cook',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const SplashScreen(),
    );
  }
}

// ---------------------------------------------------------
// 1. 스플래시 & 루트 내비게이션
// ---------------------------------------------------------
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const RootScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFF8A00), Color(0xFFFF6200)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.restaurant_menu, size: 80, color: Colors.white),
            SizedBox(height: 20),
            Text(
              'TEAM COOK',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _selectedIndex = 0;
  bool isLoggedIn = false;
  String userName = "";

  void onLoginSuccess(String name) => setState(() {
    isLoggedIn = true;
    userName = name;
  });

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = [
      const HomeScreen(),
      const ReviewListScreen(),
      const Center(child: Text('스크랩 화면')),
      MyPageScreen(
        isLoggedIn: isLoggedIn,
        userName: userName,
        onSignUpTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SignUpScreen(onSuccess: onLoginSuccess),
          ),
        ),
        onLogout: () => setState(() => isLoggedIn = false),
      ),
    ];

    return Scaffold(
      body: screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.deepOrange,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: '홈'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt), label: '요리후기'),
          BottomNavigationBarItem(icon: Icon(Icons.bookmark), label: '스크랩'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'MY'),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------
// 2. 홈 화면 (실시간 검색 기능 추가 구현 완료)
// ---------------------------------------------------------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();

  // 전체 레시피 데이터 리스트 (고추장찌개 추가)
  final List<Map<String, String>> _allRecipes = [
    {
      'name': '김치찌개',
      'score': '4.9',
      'level': '쉬움',
      'url': 'https://picsum.photos/id/102/400/300',
    },
    {
      'name': '참나물 무침',
      'score': '4.8',
      'level': '보통',
      'url': 'https://picsum.photos/id/488/400/300',
    },
    {
      'name': '봉골레 파스타',
      'score': '4.5',
      'level': '쉬움',
      'url': 'https://picsum.photos/id/429/400/300',
    },
    {
      'name': '된장찌개',
      'score': '5.0',
      'level': '보통',
      'url': 'https://picsum.photos/id/163/400/300',
    },
    {
      'name': '고추장찌개',
      'score': '4.7',
      'level': '보통',
      'url': 'https://picsum.photos/id/61/400/300',
    },
  ];

  // 검색 결과가 담길 필터링 리스트
  List<Map<String, String>> _filteredRecipes = [];

  @override
  void initState() {
    super.initState();
    _filteredRecipes = _allRecipes; // 처음에는 모든 요리 보여주기
  }

  // 검색 로직 함수
  void _filterRecipes(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredRecipes = _allRecipes;
      } else {
        _filteredRecipes = _allRecipes
            .where((recipe) => recipe['name']!.contains(query))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 20, 20, 10),
            child: Text(
              '테마별 레시피',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: TextField(
              controller: _searchController,
              onChanged: _filterRecipes, // 글자가 바뀔 때마다 실시간 검색 실행
              decoration: InputDecoration(
                hintText: '요리, 재료를 검색해주세요.',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _filterRecipes('');
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.grey.shade100,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: _filteredRecipes.isEmpty
                ? const Center(
                    child: Text(
                      '검색 결과가 없습니다.',
                      style: TextStyle(color: Colors.grey, fontSize: 16),
                    ),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(20),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 15,
                          crossAxisSpacing: 15,
                          childAspectRatio: 0.75,
                        ),
                    itemCount: _filteredRecipes.length,
                    itemBuilder: (context, index) {
                      final recipe = _filteredRecipes[index];
                      return _recipeCard(
                        context,
                        recipe['name']!,
                        recipe['score']!,
                        recipe['level']!,
                        recipe['url']!,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _recipeCard(context, name, score, level, url) => InkWell(
    onTap: () => Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => RecipeDetailScreen(title: name)),
    ),
    child: Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(15),
              ),
              child: Image.network(
                url,
                fit: BoxFit.cover,
                width: double.infinity,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.orange, size: 14),
                    Text(' $score', style: const TextStyle(fontSize: 12)),
                    const SizedBox(width: 8),
                    Text(
                      '난이도: $level',
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

// ---------------------------------------------------------
// 3. 레시피 상세 (타이머 기능 유지)
// ---------------------------------------------------------
class RecipeDetailScreen extends StatelessWidget {
  final String title;
  const RecipeDetailScreen({super.key, required this.title});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Column(
        children: [
          Image.network(
            'https://picsum.photos/id/102/600/400',
            width: double.infinity,
            height: 250,
            fit: BoxFit.cover,
          ),
          const Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Text('1. 재료를 손질합니다.', style: TextStyle(fontSize: 18)),
                SizedBox(height: 10),
                Text('2. 물을 넣고 끓입니다.', style: TextStyle(fontSize: 18)),
                SizedBox(height: 10),
                Text('3. 3분간 더 조리합니다.', style: TextStyle(fontSize: 18)),
              ],
            ),
          ),
          const Spacer(),
          Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            height: 70,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(35),
            ),
            child: const Row(
              children: [
                Icon(Icons.close, color: Colors.red),
                Spacer(),
                Text(
                  '01 : 53',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Spacer(),
                Icon(Icons.pause, color: Colors.white),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------
// 4. 요리후기 리스트 & 후기 남기기 (은기님 설계도 반영)
// ---------------------------------------------------------
class ReviewListScreen extends StatelessWidget {
  const ReviewListScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('요리후기'), centerTitle: true),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(15),
            child: Row(
              children: [
                Icon(Icons.favorite_border, color: Colors.blue),
                Text(' 내 노트만 보기'),
                Spacer(),
                Text('최신순 '),
                Icon(Icons.check, color: Colors.blue, size: 16),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                _reviewItem('은기왕', '진짜 맛있어요!'),
                _reviewItem('팀쿡조력자', '타이머 덕분에 편해요'),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const WriteReviewScreen(),
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8D5531),
                ),
                child: const Text(
                  '내 후기 남기기',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _reviewItem(String user, String text) => ListTile(
    leading: const CircleAvatar(backgroundColor: Colors.grey),
    title: Text(user, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text(text),
  );
}

class WriteReviewScreen extends StatefulWidget {
  const WriteReviewScreen({super.key});
  @override
  State<WriteReviewScreen> createState() => _WriteReviewScreenState();
}

class _WriteReviewScreenState extends State<WriteReviewScreen> {
  int _radioValue = 0; // 0: 팁, 1: 후기
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('요리후기 남기기')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Radio(
                  value: 0,
                  groupValue: _radioValue,
                  onChanged: (v) => setState(() => _radioValue = v as int),
                ),
                const Text('팁'),
                const SizedBox(width: 40),
                Radio(
                  value: 1,
                  groupValue: _radioValue,
                  onChanged: (v) => setState(() => _radioValue = v as int),
                ),
                const Text('후기'),
              ],
            ),
            const SizedBox(height: 20),
            TextField(
              maxLines: 8,
              decoration: InputDecoration(
                hintText: '다르게 사용한 재료나 나만의 조리방법이 있나요?',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              height: 180,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add, color: Colors.orange, size: 40),
                  Text('사진 추가하기(선택)'),
                ],
              ),
            ),
            const SizedBox(height: 40),
            SizedBox(
              width: double.infinity,
              height: 60,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  side: const BorderSide(color: Colors.blue),
                ),
                child: const Text(
                  '등록하기',
                  style: TextStyle(fontSize: 20, color: Colors.black),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------
// 5. 마이페이지 & 회원가입 (고도화 완료)
// ---------------------------------------------------------
class MyPageScreen extends StatelessWidget {
  final bool isLoggedIn;
  final String userName;
  final VoidCallback onSignUpTap;
  final VoidCallback onLogout;
  const MyPageScreen({
    super.key,
    required this.isLoggedIn,
    required this.userName,
    required this.onSignUpTap,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    return !isLoggedIn 
      ? LoginScreen(onLoginSuccess: onLoginSuccess, onSignUpTap: onSignUpTap)
      : _profilePage();
  }

  void onLoginSuccess(String name) {
    // 부모 RootScreen에서 처리
  }

  Widget _profilePage() => SafeArea(
    child: Column(
      children: [
        ListTile(
          contentPadding: const EdgeInsets.all(25),
          leading: const CircleAvatar(
            radius: 35,
            backgroundColor: Colors.deepOrange,
            child: Icon(Icons.person, color: Colors.white, size: 40),
          ),
          title: Text(
            '$userName님 안녕하세요!',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          subtitle: const Text('팀쿡의 회원이 되신 걸 환영해요!'),
        ),
        const Divider(thickness: 10, color: Color(0xFFF8F8F8)),
        _menu(Icons.edit, '정보 변경'),
        _menu(Icons.headset_mic, '고객센터'),
        _menu(Icons.settings, '환경설정'),
        _menu(Icons.info, '앱 정보'),
        const Spacer(),
        TextButton(
          onPressed: onLogout,
          child: const Text('로그아웃', style: TextStyle(color: Colors.grey)),
        ),
      ],
    ),
  );

  Widget _menu(icon, title) => ListTile(
    leading: Icon(icon),
    title: Text(title),
    trailing: const Icon(Icons.chevron_right),
    onTap: () {},
  );
}

// ⭐ 로그인 컴포넌트 (DB 연결됨)
class LoginScreen extends StatefulWidget {
  final Function(String) onLoginSuccess;
  final VoidCallback onSignUpTap;
  const LoginScreen({
    super.key,
    required this.onLoginSuccess,
    required this.onSignUpTap,
  });

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _pwController = TextEditingController();
  bool _isLoading = false;

  final CollectionReference _usersCollection =
      FirebaseFirestore.instance.collection('users');

  Future<void> _login() async {
    final id = _idController.text.trim();
    final pw = _pwController.text.trim();

    if (id.isEmpty || pw.isEmpty) {
      _showSnackBar('아이디와 비밀번호를 입력해주세요.', Colors.red);
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Firestore에서 login_id로 사용자 검색
      final snapshot = await _usersCollection
          .where('login_id', isEqualTo: id)
          .limit(1)
          .get();

      if (snapshot.docs.isEmpty) {
        _showSnackBar('존재하지 않는 아이디입니다.', Colors.red);
        setState(() => _isLoading = false);
        return;
      }

      // 사용자 정보 가져오기
      final userData = snapshot.docs.first.data() as Map<String, dynamic>;
      final storedPw = userData['password'] ?? '';
      final nickname = userData['nickname'] ?? '';

      // 비밀번호 검증 (현재는 평문이므로 직접 비교)
      if (storedPw != pw) {
        _showSnackBar('비밀번호가 일치하지 않습니다.', Colors.red);
        setState(() => _isLoading = false);
        return;
      }

      // 로그인 성공
      if (!mounted) return;
      widget.onLoginSuccess(nickname);
      _showSnackBar('로그인되었습니다! 🎉', Colors.green);
      Navigator.pop(context);
    } catch (e) {
      _showSnackBar('로그인 중 오류 발생: $e', Colors.red);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            '로그인',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 40),
          TextField(
            controller: _idController,
            decoration: const InputDecoration(hintText: '아이디'),
          ),
          const SizedBox(height: 15),
          TextField(
            controller: _pwController,
            obscureText: true,
            decoration: const InputDecoration(hintText: '비밀번호'),
          ),
          const SizedBox(height: 40),
          SizedBox(
            width: double.infinity,
            height: 55,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _login,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepOrange,
              ),
              child: _isLoading
                  ? const SizedBox(
                      height: 24,
                      width: 24,
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(Colors.white),
                      ),
                    )
                  : const Text('로그인', style: TextStyle(color: Colors.white)),
            ),
          ),
          TextButton(
            onPressed: widget.onSignUpTap,
            child: const Text(
              '회원가입하기',
              style: TextStyle(color: Colors.deepOrange),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _idController.dispose();
    _pwController.dispose();
    super.dispose();
  }
}

// ⭐ 고도화된 회원가입 컴포넌트
class SignUpScreen extends StatefulWidget {
  final Function(String) onSuccess;
  const SignUpScreen({super.key, required this.onSuccess});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _idController = TextEditingController();
  final TextEditingController _pwController = TextEditingController();
  final TextEditingController _pwConfirmController = TextEditingController();
  final TextEditingController _nicknameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  bool _isIdChecked = false; // 아이디 중복확인 검사 여부
  bool _isEmailChecked = false; // 이메일 중복확인 검사 여부
  bool _isPhoneVerified = false; // 휴대폰 인증 완료 여부

  final CollectionReference _usersCollection =
      FirebaseFirestore.instance.collection('users');

  Future<bool> _checkDuplicate(String field, String value) async {
    final snapshot = await _usersCollection.where(field, isEqualTo: value).limit(1).get();
    return snapshot.docs.isNotEmpty;
  }

  Future<void> _checkIdDuplicate() async {
    final id = _idController.text.trim();
    if (id.isEmpty) {
      _showSnackBar('아이디를 먼저 입력해주세요.', Colors.red);
      return;
    }
    final exists = await _checkDuplicate('login_id', id);
    setState(() => _isIdChecked = !exists);
    _showSnackBar(
      exists ? '이미 사용 중인 아이디입니다.' : '사용 가능한 아이디입니다.',
      exists ? Colors.red : Colors.green,
    );
  }

  Future<void> _checkEmailDuplicate() async {
    final email = _emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      _showSnackBar('올바른 이메일을 입력해주세요.', Colors.red);
      return;
    }
    final exists = await _checkDuplicate('email', email);
    setState(() => _isEmailChecked = !exists);
    _showSnackBar(
      exists ? '이미 사용 중인 이메일입니다.' : '사용 가능한 이메일입니다.',
      exists ? Colors.red : Colors.green,
    );
  }

  Future<void> _saveUserToFirestore() async {
    await _usersCollection.add({
      'login_id': _idController.text.trim(),
      'password': _pwController.text.trim(),
      'email': _emailController.text.trim(),
      'nickname': _nicknameController.text.trim(),
      'phone_number': _phoneController.text.trim(),
      'points': 0,
      'user_status': 'active',
      'created_at': FieldValue.serverTimestamp(),
    });
  }

  // 토스트 메시지 대용 스낵바 함수
  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('회원가입')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(25),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. 아이디 입력 + 중복확인 버튼
              const Text('아이디', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _idController,
                      decoration: const InputDecoration(
                        hintText: '아이디 입력',
                        hintStyle: TextStyle(fontSize: 14),
                      ),
                      validator: (v) =>
                          (v == null || v.isEmpty) ? '아이디를 입력해주세요.' : null,
                      onChanged: (_) {
                        if (_isIdChecked) setState(() => _isIdChecked = false);
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _checkIdDuplicate,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade800,
                    ),
                    child: Text(
                      _isIdChecked ? '확인 완료' : '중복확인',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // 2. 비밀번호 입력
              const Text('비밀번호', style: TextStyle(fontWeight: FontWeight.bold)),
              TextFormField(
                controller: _pwController,
                obscureText: true,
                decoration: const InputDecoration(
                  hintText: '비밀번호 입력(6자리 이상)',
                  hintStyle: TextStyle(fontSize: 14),
                ),
                validator: (v) =>
                    (v == null || v.length < 6) ? '비밀번호를 6자리 이상 입력해주세요.' : null,
              ),
              const SizedBox(height: 20),

              // 3. 비밀번호 확인
              const Text(
                '비밀번호 확인',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextFormField(
                controller: _pwConfirmController,
                obscureText: true,
                decoration: const InputDecoration(
                  hintText: '비밀번호 재입력',
                  hintStyle: TextStyle(fontSize: 14),
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return '비밀번호 확인을 입력해주세요.';
                  if (v != _pwController.text) return '비밀번호가 일치하지 않습니다.';
                  return null;
                },
              ),
              const SizedBox(height: 20),

              // 4. 닉네임 입력
              const Text('닉네임', style: TextStyle(fontWeight: FontWeight.bold)),
              TextFormField(
                controller: _nicknameController,
                decoration: const InputDecoration(
                  hintText: '앱에서 사용할 닉네임',
                  hintStyle: TextStyle(fontSize: 14),
                ),
                validator: (v) =>
                    (v == null || v.isEmpty) ? '닉네임을 입력해주세요.' : null,
              ),
              const SizedBox(height: 20),

              // 5. 이메일 입력
              const Text('이메일', style: TextStyle(fontWeight: FontWeight.bold)),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        hintText: 'example@gmail.com',
                        hintStyle: TextStyle(fontSize: 14),
                      ),
                      validator: (v) => (v == null || !v.contains('@'))
                          ? '올바른 이메일 형식을 입력해주세요.'
                          : null,
                      onChanged: (_) {
                        if (_isEmailChecked) setState(() => _isEmailChecked = false);
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _checkEmailDuplicate,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade800,
                    ),
                    child: Text(
                      _isEmailChecked ? '확인 완료' : '중복확인',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // 6. 휴대폰 번호 입력 + 인증 버튼
              const Text(
                '휴대폰 번호 인증',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        hintText: '01012345678 ("-" 제외)',
                        hintStyle: TextStyle(fontSize: 14),
                      ),
                      validator: (v) =>
                          (v == null || v.isEmpty) ? '휴대폰 번호를 입력해주세요.' : null,
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: () {
                      if (_phoneController.text.trim().length >= 10) {
                        setState(() => _isPhoneVerified = true);
                        _showSnackBar('휴대폰 인증이 완료되었습니다.', Colors.green);
                      } else {
                        _showSnackBar('올바른 휴대폰 번호를 입력해주세요.', Colors.red);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade800,
                    ),
                    child: Text(
                      _isPhoneVerified ? '인증 완료' : '인증하기',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 50),

              // 가입완료 버튼 실행 및 벨리데이션 체크
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: () async {
                    if (!_isIdChecked) {
                      _showSnackBar('아이디 중복확인을 해주세요.', Colors.red);
                      return;
                    }
                    if (!_isEmailChecked) {
                      _showSnackBar('이메일 중복확인을 해주세요.', Colors.red);
                      return;
                    }
                    if (!_isPhoneVerified) {
                      _showSnackBar('휴대폰 인증을 완료해주세요.', Colors.red);
                      return;
                    }
                    if (_formKey.currentState!.validate()) {
                      await _saveUserToFirestore();
                      if (!mounted) return;
                      widget.onSuccess(_nicknameController.text);
                      Navigator.pop(context);
                      _showSnackBar('회원가입을 축하합니다! 🎉', Colors.green);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                  ),
                  child: const Text(
                    '가입 완료',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
